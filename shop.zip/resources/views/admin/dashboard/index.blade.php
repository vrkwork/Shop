@extends('admin.layout.master')

@section('content')
    <div class="row">
        <div class="container">
            <ol class="breadcrumb">
                <li><a href="{{ route('dashboard') }}">Dashboard</a></li>
            </ol>
        </div>
    </div>
@endsection