<!DOCTYPE html>
<html lang="en">
<head>
    <title>{{ ucfirst($scope) }}</title>
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/bootstrap/css/bootstrap.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/style.css') }}">
</head>
<body class="body_blue_2">

<div class="navbar navbar-inverse navbar-static-top body_blue_1" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">Hi, {{ $user->username }}</a>
        </div>
        <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
                <li><a href="{{ route('dashboard')  }}">Dashboard</a></li>
                <li class="dropdown">
                    <a href="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                       aria-expanded="false">New <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="{{ route('item.create') }}">New Item Entry</a></li>
                        <li><a href="">New Supplier Entry</a></li>
                        <li><a href="">New Customer Entry</a></li>
                        <li><a href="">Create New User</a></li>
                        <li><a href="">Manage User</a></li>
                        <li><a href="">Other</a></li>
                    </ul>
                </li>
                <li><a href="">Purchase</a></li>
                <li><a href="">Sales</a></li>
                <li class="dropdown">
                    <a href="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                       aria-expanded="false">Credit Payment <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="">Customer Credit Payment</a></li>
                        <li><a href="">Supplier Credit Payment</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                       aria-expanded="false">Report <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="">Report Summary</a></li>
                        <li><a href="">Stock Report</a></li>
                        <li><a href="">Sales ID</a></li>
                        <li><a href="">Purchase ID</a></li>
                        <li><a href="">Profit / Loss</a></li>
                        <li><a href="">Cash / Credit</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                       aria-expanded="false">Other <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="">Item List</a></li>
                        <li><a href="">Supplier List</a></li>
                        <li><a href="">Customer List</a></li>
                    </ul>
                </li>
                <li><a href="">About Software</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="{{ url('auth/logout') }}">Logout</a></li>
            </ul>
        </div>
        <!--/.nav-collapse -->
    </div>
</div>

@yield('content')


<div class="footer">
    <div class="container">
        <p class="text-muted">Place sticky footer content here.</p>
    </div>
</div>

<script src="{{ asset('assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('assets/bootstrap/js/bootstrap.min.js') }}"></script>
</body>
</html>