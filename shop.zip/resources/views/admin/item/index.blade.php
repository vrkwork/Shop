@extends('admin.layout.master')

@section('content')

    <div class="row">
        <div class="container">
            <ol class="breadcrumb">
                <li><a href="{{ route('dashboard') }}">Dashboard</a></li>
                <li><a href="{{ route($scope . '.index') }}">{{ ucfirst($scope) }}</a></li>
                <li class="active">List</li>
            </ol>
        </div>
    </div>

    <div class="container">
        @include('admin.common.flash_message')

        <div class="col-sm-offset-2 col-sm-8">
            <table class="table table-hover table-bordered table_white">
                <thead>
                <tr class="info">
                    <th class="col-sm-2 text-center">SN</th>
                    <th class="col-sm-3 text-center">Item Code</th>
                    <th class="col-sm-5 text-center">Item Name</th>
                    <th class="col-sm-2 text-center"></th>
                </tr>
                </thead>
                <tbody class="text-center">
                <?php
                $count = 1;
                ?>
                @foreach($datas as $data)
                    <tr>
                        <td>{{ $count++ }}</td>
                        <td>{{ $data->item_code }}</td>
                        <td>{{ $data->item_name }}</td>
                        <td>
                            <a href="{{{ route($scope.'.edit', ['id' => $data->id]) }}}" class="btn btn-xs btn-info">
                                <i class="glyphicon glyphicon-edit"></i>
                            </a>
                            <a href="{{{ route($scope.'.destroy', ['id' => $data->id]) }}}" class="btn btn-xs btn-danger">
                                <i class="glyphicon glyphicon-trash"></i>
                            </a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>


@endsection