function allTotal() {
	var s_total = document.getElementById("sub_total").innerHTML;
	document.getElementById("total").innerHTML = s_total;
	document.getElementById("netamount").innerHTML = s_total;
}
